﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Clinic.Api.Core.Interfaces
{
    interface IPressService
    {
    }
}
