﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Clinic.Api.Core.Dto
{
    public class ClinicDto
    {

    }
    public class CreateClinicDto
    {

    }
    public class UpdateClinicDto
    {

    }
}
