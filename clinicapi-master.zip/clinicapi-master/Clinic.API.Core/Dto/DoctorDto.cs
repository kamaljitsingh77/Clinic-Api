﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Clinic.Api.Core.Dto
{
    class DoctorDto
    {
    }
    public class CreateDoctorDto
    {
    }
    public class UpdateDoctorDto
    {
    }
}
