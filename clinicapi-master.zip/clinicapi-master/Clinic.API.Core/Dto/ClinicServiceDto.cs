﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Clinic.Api.Core.Dto
{
    public class ClinicServiceDto
    {
    }
    public class CreateClinicServiceDto
    {
    }
    public class UpdateClinicServiceDto
    {
    }
}
